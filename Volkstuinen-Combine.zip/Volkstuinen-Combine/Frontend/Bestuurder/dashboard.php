<?php
require_once "Backend/SessionChecker.php";
checkSession($allowedUserTypes = [3])

?>
