<?php
require_once __DIR__ . "/../../Backend/SessionChecker.php";
checkSession($allowedUserTypes = [1])

?>
